To run execute in terminal: node server.js
After that backend service will be available on localhost:3035
----
Gustavo Yance
gusyancab@gmail.coms